
package baseespacialinternacional;

import java.util.ArrayList;


public class BaseEspacial {

    private ArrayList<UnidadOperativa> unidades;

    public BaseEspacial() {
        this.unidades = new ArrayList<>();
    }

    public void agregarUnidadOperativa(UnidadOperativa unidadop) {
        checkNull(unidadop, null);
         /*for (UnidadOperativa u : unidades) {
            if (u.getNombre().equals(unidadop.getNombre()) &&
                u.getModulo().equals(unidadop.getModulo())) {
                throw new UnidadRepetidaException("Unidad ya existente");
            }
        }*/
        if(unidades.contains(unidadop)) {
            throw new UnidadRepetidaException("Unidad ya existente");
        }
        unidades.add(unidadop);
    }
    private void checkNull(UnidadOperativa u, String mensaje) {
        if (u == null) {
            throw new IllegalArgumentException((mensaje == null) ? "Unidad nula" : mensaje);
        }
    }
    
    

    public void moverUnidades() {
        for (UnidadOperativa unidadop : unidades) {
            if (unidadop instanceof UnidadMovil um) {
                um.desplazarse();

            } else {
                System.out.println(unidadop.getNombre() + " no puede desplazarse, es unidad fija");

            }
        }

    }
    
     public void mostrarUnidades() {
        for (UnidadOperativa e : unidades) {
            System.out.println(e);

        }
    }

    
    public void realizarFuncionesBase() {
        for (UnidadOperativa u : unidades) {
            u.reabastecer();
            u.mantenerAtmosfera();
            u.replicar();
        }

    }
    
    
    public void filtrarPorTipoAtmosfera(TipoAtmosfera tipo) {
    if ((tipo == null)) {
        throw new IllegalArgumentException("Tipo no encontrado");
    }
    boolean encontrado = false;
    
    for (UnidadOperativa unidadop : unidades) {
        if (unidadop.getTipoAtmosferas() == tipo) {
            System.out.println(unidadop);
            encontrado = true;
        }
    }
    if (!encontrado) {
        throw new IllegalArgumentException("Tipo no encontrado");
    }
    }

  
    
    
    
}



