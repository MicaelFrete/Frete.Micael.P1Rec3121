
package baseespacialinternacional;

import java.util.Objects;


public abstract class UnidadOperativa {

    private String nombre;
    private String modulo;
    private TipoAtmosfera atmosferas;

    public UnidadOperativa(String nombre, String modulo, TipoAtmosfera atmosferas) {
        this.nombre = nombre;
        this.modulo = modulo;
        this.atmosferas = atmosferas;
    }

       
        public abstract void reabastecer();

        public abstract void mantenerAtmosfera();

        public abstract void replicar();

        @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if ((other == null) || !(other instanceof UnidadOperativa uop)) {
            return false;
        }
        return nombre.equals(uop.nombre) && modulo.equals(uop.modulo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
      
    public String getNombre() {
        return nombre;
    }

    public String getModulo() {
        return modulo;
    }

    public TipoAtmosfera getTipoAtmosferas() {
        return atmosferas;
    }
    

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + " Nombre: " + nombre + 
               " Módulo: " + modulo + "  Atmósfera: " + atmosferas;
    }
    
    
}


