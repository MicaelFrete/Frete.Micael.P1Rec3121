
package baseespacialinternacional;


public enum TipoAtmosfera {
    PRESURIZADA,
    VACIO
}
