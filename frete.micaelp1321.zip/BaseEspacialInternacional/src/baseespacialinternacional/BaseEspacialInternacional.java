package baseespacialinternacional;


public class BaseEspacialInternacional {

    public static void main(String[] args) {
        
        BaseEspacial base = new BaseEspacial();
        hardcodearUnidades(base);
        
        base.mostrarUnidades();
        
        base.filtrarPorTipoAtmosfera(TipoAtmosfera.VACIO);
        base.moverUnidades();
        base.realizarFuncionesBase();
    }

   

    public static void hardcodearUnidades(BaseEspacial base) {

       base.agregarUnidadOperativa(new Astronauta("Cmdr. Vega", "Pluton", TipoAtmosfera.PRESURIZADA, 15));
       base.agregarUnidadOperativa(new Robot("Rover_R2", "Marte", TipoAtmosfera.VACIO, 48));
       base.agregarUnidadOperativa(new Robot("Drone_X1", "Marte", TipoAtmosfera.PRESURIZADA, 24));            
       base.agregarUnidadOperativa(new Experimento("Crecimiento_S", "Pluton", TipoAtmosfera.PRESURIZADA, 100));
       //base.agregarUnidadOperativa(new Astronauta("Cmdr. Vega", "Pluton", TipoAtmosfera.VACIO, 14));
       
       

}
    
}
