/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacialinternacional;

public class Robot extends UnidadOperativa implements UnidadMovil {
    private int autonomiaOperativa;
    
    public Robot(String nombre, String modulo, TipoAtmosfera atmosfera, int autonomiaOperativa) {
        super(nombre, modulo, atmosfera);
        this.autonomiaOperativa = autonomiaOperativa;
    }
    
    @Override
    public void reabastecer() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " recarga su batería.");
    }

    @Override
    public void mantenerAtmosfera() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " regula condiciones del módulo.");
    }

    @Override
    public void replicar() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " copia su software a un nuevo robot.");
    }

    @Override
    public String toString() {
        return super.toString() + "Autonomía para operara: " + autonomiaOperativa + "h";
    }
    
    @Override
    public void desplazarse() {
        System.out.println("Me estoy moviendo");
    }
    
  
}

