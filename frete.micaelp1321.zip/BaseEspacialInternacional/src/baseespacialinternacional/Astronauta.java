/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacialinternacional;


public class Astronauta extends UnidadOperativa implements UnidadMovil {

    private int maxCantidadEVA;

   public Astronauta(String nombre, String modulo, TipoAtmosfera atmosfera, int maxCantidadEVA) {
        super(nombre, modulo, atmosfera);
        this.maxCantidadEVA = maxCantidadEVA;
}

    @Override
    public void reabastecer() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " se alimenta y recarga oxígeno.");
    }

    @Override
    public void mantenerAtmosfera() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " verifica presión y temperatura del módulo.");
    }

    @Override
    public void replicar() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " entrena a un nuevo astronauta.");
    }
   
   @Override
    public String toString() {
        return super.toString() + "Maxima Cantidad Horas: " + maxCantidadEVA + "h";
    }
   
    @Override
    public void desplazarse() {
        System.out.println("Me estoy moviendo");
    }
}