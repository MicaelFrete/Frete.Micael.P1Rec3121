/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baseespacialinternacional;


public class Experimento extends UnidadOperativa {

    private int duracionIdeal;

    public Experimento(String nombre, String modulo, TipoAtmosfera atmosfera, int duracionIdeal) {
        super(nombre, modulo, atmosfera);
        this.duracionIdeal = duracionIdeal;
    }

    @Override
    public void reabastecer() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " recibe suministro para continuar el experimento.");
    }

    @Override
    public void mantenerAtmosfera() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " mantiene condiciones.");
    }

    @Override
    public void replicar() {
        System.out.println(getClass().getSimpleName() + ": " + getNombre() + " replica su protocolo experimental.");
    }
    
    @Override
    public String toString() {
        return super.toString() + "| Duración Ideal: " + duracionIdeal + " días";
    }
    
}
