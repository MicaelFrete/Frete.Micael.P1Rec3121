
package gestionexcavacionarqueologica;


public enum TipoEdificacion {
    TEMPLO,
    VIVIENDA;
}
