/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexcavacionarqueologica;

/**
 *
 * @author Micael
 */
public class HerramientaAntigua extends Hallazgo implements Analizable{

    private String material;
    private double usoProbable;

    public HerramientaAntigua(String sitioDescubierto, String fechaDescubrimiento, int estadoConservacion, String material, double usoProbable) {
        super(sitioDescubierto, fechaDescubrimiento, estadoConservacion);
        this.material = material;
        this.usoProbable = usoProbable;
    }

    @Override
    public String toString() {
        return super.toString() + "material=" + material + ", usoProbable=" + usoProbable + '}';
    }
    
    @Override
    public void analizar() {
        System.out.println("Soy " + getClass().getSimpleName() + " y estoy siendo analizado");
    }
    
    
    

}
