
package gestionexcavacionarqueologica;

public class HallazgoRepetidoException  extends RuntimeException {
        
    private static final String MESSAGE = "Hallazgo repetido";


    public HallazgoRepetidoException() {
        this(MESSAGE);
    }
    
    public HallazgoRepetidoException(String mensaje) {
        super(mensaje);
    }

}
