
package gestionexcavacionarqueologica;


public enum EpocaHistorica {
    PRECOLOMBINA,
    COLONIAL,
    MODERNA;
}
