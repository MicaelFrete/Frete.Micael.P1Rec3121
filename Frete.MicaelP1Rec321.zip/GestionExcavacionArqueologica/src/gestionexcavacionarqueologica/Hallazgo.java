
package gestionexcavacionarqueologica;

import java.util.ArrayList;
import java.util.Objects;


public abstract class Hallazgo {
    private String sitioDescubierto;
    private String fechaDescubrimiento;
    private int estadoConservacion;
    private static final int ID_AUTOINCREMENTAL = 50000;

    public Hallazgo(String sitioDescubierto, String fechaDescubrimiento, int estadoConservacion) {
        this.sitioDescubierto = sitioDescubierto;
        this.fechaDescubrimiento = fechaDescubrimiento;
        this.estadoConservacion = estadoConservacion;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " {sitioDescubierto=" + sitioDescubierto + 
                ", fechaDescubrimiento=" + fechaDescubrimiento + 
                ", estadoConservacion=" + estadoConservacion + 
                ", ID_AUTOINCREMENTAL=" + ID_AUTOINCREMENTAL + '}';
    }
    
    
        @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if ((other == null) || !(other instanceof Hallazgo h)) {
            return false;
        }
        return sitioDescubierto.equals(h.sitioDescubierto) && fechaDescubrimiento.equals(h.fechaDescubrimiento);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sitioDescubierto, fechaDescubrimiento);
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }
    


    
}
