/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexcavacionarqueologica;

import java.util.ArrayList;

public class DescubrimientoArqueologico {

    private ArrayList<Hallazgo> hallazgos;

    public DescubrimientoArqueologico() {
        this.hallazgos = new ArrayList<>();
    }

    public void registrarHallazgo(Hallazgo nuevoHallazgo) {
        checkNullHallazgo(nuevoHallazgo, null);

        if (hallazgos.contains(nuevoHallazgo)) {
            throw new HallazgoRepetidoException("Hallazgo ya existente");
        }
        hallazgos.add(nuevoHallazgo);
    }

    private void checkNullHallazgo(Hallazgo hallazgo, String mensaje) {
        if (hallazgo == null) {
            throw new IllegalArgumentException((mensaje == null) ? "Hallazgo nulo" : mensaje);
        }
    }

    public void mostrarHallazgos() {
        for (Hallazgo h : hallazgos) {
            System.out.println(h);

        }
    }

    public void analizarHallazgo() {
        for (Hallazgo hallazgo : hallazgos) {
            if (hallazgo instanceof Analizable a) {
                a.analizar();

            } else {
                System.out.println(hallazgo.getClass().getSimpleName() + " no debe analizarse");

            }
        }

    }

    public void restaurarRuina() {
        for (Hallazgo hallazgo : hallazgos) {
            if (hallazgo instanceof Restaurable r) {
                r.restaurar();

            } else {
                System.out.println(hallazgo.getClass().getSimpleName() + " no tiene que restaurarse");

            }
        }

    }

    public ArrayList<Hallazgo> filtrarPorEpoca(EpocaHistorica epocaBuscada) {
        ArrayList<Hallazgo> filtrados = new ArrayList<>();

        for (Hallazgo h : hallazgos) {
            if (h instanceof Ruina) {
                Ruina r = (Ruina) h;
                if (r.getEpocas() == epocaBuscada) {
                    filtrados.add(r);
                    System.out.println(r);
                }
            }
        }

        return filtrados;
    }

    private void validarConservacion(int desde, int hasta) {
        if (desde < 1 || hasta > 10) {
            throw new IllegalArgumentException("El estado de conservación debe estar entre 1 y 10");
        }
    }

    public ArrayList<Hallazgo> filtrarPorEstado(int desde, int hasta) {
        validarConservacion(desde, hasta);
        
        ArrayList<Hallazgo> filtrados = new ArrayList<>();

        for (Hallazgo h : hallazgos) {
            int estado = h.getEstadoConservacion();
            if (estado >= desde && estado <= hasta) {
                filtrados.add(h);
                System.out.println(h);
            }
        }

        return filtrados;
    }

}
