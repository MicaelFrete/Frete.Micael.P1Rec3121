

package gestionexcavacionarqueologica;


public class GestionExcavacionArqueologica {


    public static void main(String[] args) {
        
     DescubrimientoArqueologico descubrimiento = new DescubrimientoArqueologico();

    hardcodearHallazgos(descubrimiento);
     
    
    descubrimiento.mostrarHallazgos();
    descubrimiento.analizarHallazgo();
    descubrimiento.restaurarRuina();
    descubrimiento.filtrarPorEpoca(EpocaHistorica.PRECOLOMBINA);
    descubrimiento.filtrarPorEstado(1, 10);
 
    }

   

    public static void hardcodearHallazgos(DescubrimientoArqueologico descubrimiento) {

      descubrimiento.registrarHallazgo(new RestoFosil("Mendoza", "1-01-1997", 10, "Dinosaurio", false));
      descubrimiento.registrarHallazgo(new Ruina("Corrientes", "8-02-1988", 2, TipoEdificacion.TEMPLO, EpocaHistorica.COLONIAL));
      descubrimiento.registrarHallazgo(new HerramientaAntigua("España", "18-02-1540", 5, "hierro", 50.0));
      //descubrimiento.registrarHallazgo(new HerramientaAntigua("España", "18-02-1540", 8, "Cobre", 58.5));
            
      
    }
    
}
