
package gestionexcavacionarqueologica;


public interface Restaurable {
    void restaurar();
}
