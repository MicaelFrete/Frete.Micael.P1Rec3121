/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionexcavacionarqueologica;

/**
 *
 * @author Micael
 */
public class RestoFosil extends Hallazgo implements Analizable{

    private String especie;
    private boolean esqueloCompleto;

    public RestoFosil(String sitioDescubierto, String fechaDescubrimiento, int estadoConservacion, String especie, boolean esqueletoCompleto) {
        super(sitioDescubierto,fechaDescubrimiento,estadoConservacion);
        this.especie = especie;
        this.esqueloCompleto = esqueletoCompleto;
    }

    @Override
    public String toString() {
        return super.toString() + "especie=" + especie + ", esqueloCompleto=" + esqueloCompleto + '}';
    }

    @Override
    public void analizar() {
        System.out.println("Soy " + especie + " y estoy siendo analizado");
    }
    

    
    
    
    
    
    
    
    
}
