
package gestionexcavacionarqueologica;


public class Ruina extends Hallazgo implements Restaurable {

    private TipoEdificacion tipos;
    private EpocaHistorica epocas;

    public Ruina(String sitioDescubierto, String fechaDescubrimiento, int estadoConservacion, TipoEdificacion tipos, EpocaHistorica epocas) {
        super(sitioDescubierto, fechaDescubrimiento, estadoConservacion);
        this.tipos = tipos;
        this.epocas = epocas;
    }

    @Override
    public String toString() {
        return super.toString() + "tipos=" + tipos + ", epocas=" + epocas + '}';
    }

    @Override
    public void restaurar() {
        System.out.println("Soy " + getClass().getSimpleName() + " y puedo ser restaurado");
    }

    public EpocaHistorica getEpocas() {
        return epocas;
    }

    public boolean esEpoca(EpocaHistorica tipo) {
        return this.getEpocas() == tipo;
    }

}
