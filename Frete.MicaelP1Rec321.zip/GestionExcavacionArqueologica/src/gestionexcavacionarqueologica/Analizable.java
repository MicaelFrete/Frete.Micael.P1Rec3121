
package gestionexcavacionarqueologica;


public interface Analizable {
    
    
    void analizar();
}
